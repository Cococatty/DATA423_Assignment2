Folder to put images for word clouds
