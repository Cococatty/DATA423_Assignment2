First Data + Art Proj

More to come!
