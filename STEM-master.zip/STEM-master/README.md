# STEM

An introduction to the Data + Art STEAM project with Forest Hill Junior and Senior Public School in Toronto! 

Link to full [article](https://www.littlemissdata.com/blog/steam-data-art1)
